use clap::{Parser, Subcommand};
use compass_core::{Error, Result, codec, compare, storage};
use serde_json::{Value, json};
use std::{
    io::{self, Write},
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

#[derive(Parser)]
#[command(
    name = "compass",
    version,
    about = "Observe and compare local repository states with explicit provenance"
)]
struct Cli {
    #[arg(
        long,
        global = true,
        help = "Write one canonical JSON object to stdout"
    )]
    json: bool,
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Create a persistent identity and default observation policy.
    Init {
        #[arg(long)]
        root: PathBuf,
    },
    /// Observe eligible files and publish an immutable manifest.
    Snapshot {
        #[arg(long)]
        root: PathBuf,
    },
    /// Compare two saved manifests without accessing their source tree.
    Compare {
        #[arg(long)]
        baseline: PathBuf,
        #[arg(long)]
        current: PathBuf,
    },
}

fn run(cli: &Cli, cancel: &AtomicBool) -> Result<(Value, i32)> {
    match &cli.command {
        Command::Init { root } => Ok((
            serde_json::to_value(storage::init(root, cancel)?)
                .map_err(|e| Error::corrupt(e.to_string()))?,
            0,
        )),
        Command::Snapshot { root } => {
            let receipt = storage::snapshot(root, cancel)?;
            let code = if receipt.quality == "partial" { 3 } else { 0 };
            Ok((
                serde_json::to_value(receipt).map_err(|e| Error::corrupt(e.to_string()))?,
                code,
            ))
        }
        Command::Compare { baseline, current } => {
            let baseline = storage::load_snapshot(baseline)?;
            let current = storage::load_snapshot(current)?;
            let comparison = compare::compare(&baseline, &current)?;
            let code = if comparison.quality == "partial" {
                3
            } else {
                0
            };
            Ok((
                serde_json::to_value(comparison).map_err(|e| Error::corrupt(e.to_string()))?,
                code,
            ))
        }
    }
}

fn output(value: &Value, as_json: bool) -> Result<()> {
    let bytes = if as_json {
        codec::canonical(value)?
    } else {
        serde_json::to_vec_pretty(value).map_err(|e| Error::corrupt(e.to_string()))?
    };
    let mut stdout = io::stdout().lock();
    stdout
        .write_all(&bytes)
        .and_then(|_| stdout.write_all(b"\n"))
        .and_then(|_| stdout.flush())
        .map_err(|e| Error::io("write stdout", e))
}

fn fail(error: Error, as_json: bool) -> i32 {
    if as_json {
        if let Err(output_error) = output(
            &json!({"error":{"code":error.code,"message":error.message}}),
            true,
        ) {
            eprintln!("{output_error}");
        }
    } else {
        eprintln!("{}: {}", error.code, error.message);
    }
    error.exit_code
}

fn main() -> std::process::ExitCode {
    let wants_json = std::env::args_os().any(|a| a == "--json");
    let cli = match Cli::try_parse() {
        Ok(cli) => cli,
        Err(e) if e.exit_code() == 0 => {
            let _ = e.print();
            return std::process::ExitCode::SUCCESS;
        }
        Err(e) => {
            return std::process::ExitCode::from(
                fail(Error::invalid(e.to_string()), wants_json) as u8
            );
        }
    };
    let cancel = Arc::new(AtomicBool::new(false));
    if let Err(e) = signal_hook::flag::register(signal_hook::consts::SIGINT, Arc::clone(&cancel)) {
        return std::process::ExitCode::from(fail(
            Error::io("register interrupt handler", e),
            cli.json,
        ) as u8);
    }
    let result = run(&cli, &cancel);
    if cancel.load(Ordering::Relaxed) {
        return std::process::ExitCode::from(fail(Error::cancelled(), cli.json) as u8);
    }
    let status = match result {
        Ok((value, code)) => match output(&value, cli.json) {
            Ok(()) => code,
            Err(e) => fail(e, false),
        },
        Err(error) => fail(error, cli.json),
    };
    std::process::ExitCode::from(status as u8)
}
