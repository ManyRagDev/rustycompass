#[cfg(not(target_os = "linux"))]
compile_error!("Compass Foundation 0.1 supports Linux only; see the filesystem contract.");

pub mod codec;
pub mod compare;
mod error;
pub mod model;
pub mod observe;
pub mod storage;

pub use error::{Error, Result};

pub const BUILD_ID: &str = env!("COMPASS_BUILD_ID");
