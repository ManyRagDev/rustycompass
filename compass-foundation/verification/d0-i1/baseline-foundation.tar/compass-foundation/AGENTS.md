# Instruções do Compass Foundation

Leia `COMPASS_STATE.md` e `research/contracts/FOUNDATION.md` antes de alterar comportamento. A direção de produto está em `../compass-documento-principal/COMPASS_DOCUMENTO_PRINCIPAL.md`; os arquivos dessa edição são uma referência preservada.

O núcleo Rust é a única implementação de produção. A CLI chama esse núcleo. Python em `verification/` é verificação independente. Não importar código, testes ou instruções do legado nem ampliar Foundation para D0, grafos, embeddings ou MCP sem uma tarefa correspondente.

Preserve gabaritos independentes. Uma divergência legítima no contrato exige uma alteração explícita do contrato e de seus consumidores; não ajuste o esperado só para fazer o código passar.

Build e testes: `scripts/cargo-local.sh test --workspace --locked --offline`. Verificação independente: consulte `verification/ACCEPTANCE.md`. Execute formatação e Clippy ao concluir mudanças Rust. Não atribua resultados a um commit inexistente ou a uma árvore diferente do build testado.

## Uso eficiente de contexto e agentes

Emanuel solicitou controle de consumo sem reduzir os critérios de qualidade. Trabalhe por entregas pequenas, cada uma com escopo, critérios de aceite e evidências; preserve o progresso em `COMPASS_STATE.md` para evitar reconstruir o histórico.

O fluxo de conversas, dependências e prompts da próxima etapa está em `docs/COORDENACAO.md`. Execute apenas a entrega atribuída na conversa; reporte seu resultado para a coordenação conferir antes de liberar consumidores dependentes.

- Leia o estado e os arquivos pertinentes à mudança; releia documentos completos somente quando a questão depender deles. Limite a saída das ferramentas aos trechos necessários.
- Use agentes apenas quando houver trabalho distinto que justifique a delegação. Prefira um implementador e uma revisão independente posterior; paralelismo adicional precisa de benefício concreto. Evite delegar tarefas triviais.
- Dê aos agentes um resumo suficiente, os caminhos necessários e critérios de aceite. Não copie automaticamente toda a conversa quando o contexto específico bastar. Não faça dois agentes repetirem a mesma investigação sem razão de verificação.
- Modelo e esforço são escolhas explícitas do usuário ou de instruções aplicáveis; não pressuponha que todos devam usar Astra Extra Alto. As recomendações de outro modelo não equivalem a uma configuração já aplicada.
- Mantenha testes de contrato e revisão independente. Execute testes focados durante a implementação e a verificação integrada ao fechar a entrega; repita apenas o que mudanças ou falhas justificarem. Conclua formatação e ajustes nos inputs do build antes de capturar os hashes e resultados finais.
- Em entregas substanciais, consulte o uso da conta no início e no fim quando a ferramenta estiver disponível. Registre a diferença como aproximação compartilhada com outros trabalhos, nunca como contagem exata de tokens deste projeto. Não prometa economia percentual sem medição.
- Se a mesma abordagem falhar repetidamente, explicite a hipótese e o bloqueio antes de iniciar outro ciclo semelhante. Escale a análise somente onde a dificuldade justificar.
