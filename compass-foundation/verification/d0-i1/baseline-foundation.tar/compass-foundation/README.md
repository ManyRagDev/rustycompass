# Compass Foundation

Primeiro componente do Compass D0: observa uma árvore local, registra revisões por SHA-256 e compara manifestos sem consultar novamente o acervo. Motor e CLI em Rust; Python é usado somente na verificação independente.

Suporte inicial: Linux com `openat2` (kernel 5.6 ou posterior). A observação é uma janela de leitura, não um snapshot atômico. Arquivos vazios, binários e nomes não UTF-8 são suportados. O resultado distingue diferença conhecida de observação parcial.

## Compilar

A toolchain está fixada em Rust 1.90.0 e as dependências em `Cargo.lock`. Neste workspace, Rust foi instalado em `../.tooling/`, sem modificar o PATH global. O wrapper também funciona com uma instalação Rust convencional quando essa pasta não existe.

```bash
./scripts/cargo-local.sh build --release --locked
./target/release/compass --help
```

Depois do primeiro download de dependências, builds e testes podem usar `--offline`.

## Usar

```bash
./target/release/compass init --root /caminho/do/acervo --json
./target/release/compass snapshot --root /caminho/do/acervo --json
```

`init` cria `.compass/` com identidade e política; repetir o comando preserva a identidade. `snapshot` devolve o caminho do manifesto. Após alterar o acervo, execute outro snapshot e compare os caminhos devolvidos:

```bash
./target/release/compass compare \
  --baseline /caminho/do/primeiro.json \
  --current /caminho/do/segundo.json \
  --json
```

Sem `--json`, a saída usa JSON identado legível. Com a opção, stdout contém um objeto canônico por execução. Encontrar diferenças é sucesso operacional, código `0`; resultado parcial retorna `3`, erro operacional/registro inválido `1`, configuração ou comparação incompatível `2`, e SIGINT `130`.

Os campos `*_path` dos recibos são auxiliares para exibição. Para automação que aceite qualquer nome Linux, decodifique `*_path_base64`: base64url sem padding dos bytes do caminho absoluto. Os caminhos relativos dentro dos manifestos usam `path_key`, também com preservação de bytes.

## Política de observação

A configuração efetiva está em `.compass/policy.json` e é copiada para cada manifesto. Ela inclui exclusões e limites de arquivos, bytes, entradas e duração. Os limites são strings decimais positivas ou `null` quando não configurados. Configurações inválidas são rejeitadas; alteração de política impede comparar snapshots como se tivessem o mesmo universo.

Duração e cancelamento são cooperativos entre operações. Não interrompem uma chamada de filesystem bloqueada, como pode ocorrer em NFS. Sem limites configurados, o tamanho do manifesto e a memória crescem com o inventário.

Por padrão, diretórios `.git`, `.compass`, `.aws` e `.ssh`, arquivos `.env` e `.env.*`, links e tipos especiais são excluídos. `.gitignore` não é aplicado implicitamente. Exclusões adicionais em `exclude_paths` são caminhos relativos codificados em base64url sem padding. `node_modules` e `target` devem ser excluídos explicitamente quando não fazem parte do acervo desejado.

O conteúdo é identificado por seus bytes, sem normalização. Renomeações aparecem como remoção e adição. A permissão de execução integra o estado; mudanças somente em mtime não alteram a revisão.

## Verificar

```bash
./scripts/cargo-local.sh test --workspace --locked --offline
./scripts/cargo-local.sh fmt --all -- --check
./scripts/cargo-local.sh clippy --workspace --all-targets --locked --offline -- -D warnings
python3 verification/reference/acceptance.py --help
```

Para repetir a carga de recursos de 1.000 arquivos (requer `/usr/bin/time`):

```bash
python3 verification/reference/profile.py \
  --binary target/release/compass \
  --output verification/results/local-profile.json
```

Os gabaritos manuais e o mapeamento F01–F20 estão em [verificação](verification/ACCEPTANCE.md). O [contrato ativo](research/contracts/FOUNDATION.md) e o [schema de transporte](research/contracts/transport.schema.json) definem o comportamento, inclusive as limitações da leitura concorrente.

## Escopo e proveniência

Esta entrega guarda manifestos, sem blobs de conteúdo. Ela não calcula D0, recupera contexto, cria embeddings ou grafos, nem fornece MCP ou interface gráfica. D0 textual futuro precisará de fontes dos bytes antigos ou de uma política explícita de retenção.

O build inclui `producer_build`, um SHA-256 dos fontes, manifests Cargo, lockfile, toolchain e contratos, incluindo alterações locais. Esse identificador não depende de existir um commit e não equivale a uma assinatura de autoria.

A [edição documental original](../compass-documento-principal/COMPASS_DOCUMENTO_PRINCIPAL.md) é a autoridade de produto. A [análise inicial](../docs/ANALISE_INICIAL.md) explica a decomposição da implementação. Esses materiais permanecem fora deste repositório de código e preservados no diretório pai. O [estado operacional](COMPASS_STATE.md) registra verificações e limitações desta versão.
